<html>
<head>
<title>Okezone - Portal Berita No. 1</title>
<link href="./css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="./css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="./css/bootswatch.css" rel="stylesheet" media="screen">
</head>
<body>
<div class="navbar navbar-inverse navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="brand" href="index.php">UDINUS News</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav">
                            <li><a class="brand" style="margin-left:1000px;">by PSI-Udinus</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
<div class="container-fluid">
            <div class="row-fluid">
                <div class="span3">
                <div class="well sidebar-nav">
    <ul class="nav nav-list">
        <font color="black"><b>Menu : </b></font><br>
        <li><a href="#">Home</a></li>
    <li><a href="about.html">About</a></li>
    <li><a href="/blog">Blog</a></li>
    <li><a href="contact.html">Contact Us</a></li>
        
    </ul>
</div>
                </div><!--/span-->
            <div class="span9">
                    <!--letak konten-->
                    <div class="row-fluid">
      <div class="span4">
        <img data-src="holder.js/300x200" alt="300x200" src="./img/ratna.jpg" style="width: 300px; height: 200px;">
      </div>
      <div class="span8">
          <h2>Berkas Ratna Sarumpaet Dilimpahkan<br>ke Kejati</h2>
          <p style="text-align:justify;">"Kami limpahkan tanggal 10 (Kamis 10 Januari," kata Kepala Sub Direktorat Kejahatan dan Kekerasan Direktorat Reserse Kriminal Umum Polda Metro Jaya AKBP Jerry Siagian saat dikonfirmasi ...</p>
          <p>
            <a href="./blog/artikel.html" class="btn btn-primary">Baca Selengkapnya</a> 
            <a href="#" class="btn btn-inverse">Diposkan pada Senin, 11 November 2019</a>
          </p>
          
      </div>
      </div>
      <hr>
      <div class="row-fluid">
      <div class="span4">
        <img data-src="holder.js/300x200" alt="300x200" src="./img/higuain.jpg" style="width: 300px; height: 200px;">
      </div>
      <div class="span7">
          <h2>Higuain Sulit, Chelsea kini Incar Cavani</h2>
          <p style="text-align:justify;">Bahkan demi merealisasikan rencana itu, Chelsea kabarnya segera melayangkan penawaran resmi ke PSG dalam waktu dekat ini. Menurut laporan The Guardian, Senin (7/1/2019), Chelsea diklaim bakal menawarkan uang sebesar 53 juta pounds atau sekira Rp950 miliar kepada PSG untuk melepas Cavani.</p>
          <p>
            <a href="./blog/artikel2.html" class="btn btn-primary">Baca Selengkapnya</a> 
            <a href="#" class="btn btn-inverse">Diposkan pada Senin, 11 November 2019</a>
          </p>
          <hr>
      </div>       
    </div>
      </div>
      </div>
      <hr>
      
      <br><br>
<footer>Copyright &copy; Evan Fadilla Hafidz</footer>
</div>
</body>
</html>